n=input("en ur no")
b=input("en ur no")
c=n+b
print c
